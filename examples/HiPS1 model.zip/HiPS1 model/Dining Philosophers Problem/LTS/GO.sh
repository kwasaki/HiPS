#!/bin/sh

bcg_open DPP_5.bcg exhibitor -dfs < deadlock.seq

