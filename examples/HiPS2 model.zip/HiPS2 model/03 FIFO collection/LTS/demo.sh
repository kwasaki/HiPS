#!/bin/sh

bcg_io -aldebaran check.aut -bcg check.bcg
bcg_labels -hide hidingLabels.hid -rename renamingLabels.hid check.bcg check_hide.bcg
bcg_info -labels check_hide.bcg
bcg_min -observational check_hide.bcg check_omin.bcg
bcg_info check_hide.bcg

# bcg_draw -ps check_omin.bcg

rm *.o
